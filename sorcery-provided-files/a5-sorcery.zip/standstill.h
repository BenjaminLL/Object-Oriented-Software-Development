#ifndef _STANDSTILL_H_
#define _STANDSTILL_H_
#include "ritual.h"
#include <string>

class StandStill : public Ritual {
protected:
    std::string Desc;
public:
    StandStill();
    std::string getName() override;
    std::string getType() override;
    std::string getDesc() override;
};


#endif
