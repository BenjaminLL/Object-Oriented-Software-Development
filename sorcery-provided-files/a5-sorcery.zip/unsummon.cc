#include "unsummon.h"
using namespace std;

Unsummon::Unsummon() : Spell{1}, Desc{"Put target minion on the bottom of its owner's deck"} {}

string Unsummon::getName() {
    return "Unsummon";
}

string Unsummon::getType() {
    return "spell";
}

string Unsummon::getDesc() {
    return Desc;
}
