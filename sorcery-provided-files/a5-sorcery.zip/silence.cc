#include "enchantments.h"
#include "silence.h"
using namespace std;

Silence::Silence() :Enchantments{1} {}

string Silence::getDesc() {
    return "Enchanted minion cannot use abilities";
}

string Silence::getName() {
	return "Silence";
}


string Silence::getType() {
	return "enchantment";
}
