#ifndef _GRAVEYARD_H_
#define _GRAVEYARD_H_
#include "collection.h"

class Graveyard: public Collection {
  public:
    Graveyard();
    ~Graveyard() override;
};

#endif
