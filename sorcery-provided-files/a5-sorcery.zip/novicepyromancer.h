#ifndef _NOVICEPYROMANCER_H_
#define _NOVICEPYROMANCER_H_
#include "minion.h"
#include <string>

class NovicePyromancer : public Minion {
protected:
    std::string Desc;
    int ability_cost;
    int extra_cost = 0;
    
public:
    NovicePyromancer();
    std::string getName() override;
    std::string getType() override;
    std::string getDesc() override;
    int getAbilityCost() override;
    void addExtraCost(int i) override;
    void clear_extra_cost() override;
    
};

#endif
