#ifndef _RITUAL_H_
#define _RITUAL_H_
#include "cards.h"
#include <string>

class Ritual : public Cards {
protected:
    int ritualcost;
    int charge;
    
public:
    Ritual(int cost, int ritualcost, int charge);
    ~Ritual() override;
    int getRitualCost() override;
    int getRitualCharges() override;
    void addRitualCharges(int i) override;
};

#endif
