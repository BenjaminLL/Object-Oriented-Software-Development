#include "raisedead.h"
using namespace std;

RaiseDead::RaiseDead() : Spell{1}, Desc{"Resurrect the top minion in your graveyard"} {}

string RaiseDead::getName() {
    return "Raise Dead";
}

string RaiseDead::getType() {
    return "spell";
}

string RaiseDead::getDesc() {
    return Desc;
}
