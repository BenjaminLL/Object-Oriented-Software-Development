#include "recharge.h"
using namespace std;

Recharge::Recharge() : Spell{1}, Desc{"Your ritual gains 3 charges"} {}

string Recharge::getName() {
    return "Recharge";
}

string Recharge::getType() {
    return "spell";
}

string Recharge::getDesc() {
    return Desc;
}
