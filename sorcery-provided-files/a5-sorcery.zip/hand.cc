#include "hand.h"

Hand::Hand() {}
Hand::~Hand() {}


std::shared_ptr<Cards> Hand::getRitual() {
    std::shared_ptr<Cards> a;
    return a;
}

bool Hand::hasRitual() {return false;}
void Hand::shuffle() {return;}
