#ifndef _RaiseDead_H_
#define _RaiseDead_H_
#include "spell.h"
#include <string>

class RaiseDead : public Spell {
protected:
    std::string Desc;
    
public:
    RaiseDead();
    std::string getName() override;
    std::string getType() override;
    std::string getDesc() override;
};

#endif
