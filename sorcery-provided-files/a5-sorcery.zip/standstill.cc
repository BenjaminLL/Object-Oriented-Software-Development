#include "standstill.h"
using namespace std;

StandStill::StandStill() : Ritual{3, 2, 4}, Desc{"Whenever a minion enters play, destroy it"} {}

string StandStill::getName() {
    return "Standstill";
}

string StandStill::getType() {
    return "ritual";
}

string StandStill::getDesc() {
    return Desc;
}
