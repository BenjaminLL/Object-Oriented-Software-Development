#include <iostream>
#include "game.h"
#include <string>
#include <sstream>
#include <fstream>
using namespace std;

int main(int argc, char *argv[]) {
	string deck1 = "default.deck";
	string deck2 = "default.deck";
	string init_file = "";
	bool test = false;

	if (argc > 1) {
		for (int i = 1; i < argc; ++i) {
			string argument = argv[i];
			if (argument == "-deck1") {
				deck1 = argv[i+1];
				++i;
			} else if (argument == "-deck2") {
				deck2 = argv[i+1];
				++i;
			} else if (argument == "-init") {
				init_file = argv[i+1];
				++i;
			} else if (argument == "-testing") {
				test = true;
			}
		}
	}

	ifstream file{init_file};
	string name1 = "player1";
	string name2 = "player2";
	vector<string> command_list;
	string temp;

	file >> name1;
	if (file) {
		file >> name2;
		if (file) {
			while (1) {
				getline(file, temp);
				if (!file) break;
				command_list.push_back(temp);
			}
		}
	}
    
	Game game;
	try {
		game.initial(deck1,deck2,test,name1,name2);
	} catch (string m) {
		cout << m << endl;
	}

	string command;
	int player = 0;
    int start = 0;
    bool first_turn = false;
    bool first_round = true;
    
    vector<string> initial_command;
    while (1) {
        
        if (first_turn) {
            game.getMagic(player);
            game.draw(player);
            first_turn = false;
        }
        
        
        if (start == 0) {
            game.begin_ritual(player);
            ++start;
        }
        
        if (first_round) {
            game.displayBoard();
            first_round = false;
        }
        
		if (command_list.size() > 0) {
			
            string temp =command_list[0];
            istringstream ss{temp};
            ss >> command;
            string other;
            while (ss >> other) {
                initial_command.push_back(other);
            }
			command_list.erase(command_list.begin());
		} else {
			cin >> command;
			if (!cin) break;
		}
		
		if (command == "help") {
			cout << "Commands: help -- Display this message." << endl;
			cout << "          end -- End the current player's turn." << endl;		
			cout << "          quit -- End the game." << endl;
			cout << "          attack minion other-minion -- Orders minion(pos) to attack other-minion.(pos)" << endl;
			cout << "          attack minion -- Orders minion to attack the opponent." << endl;
			cout << "          play card [target-player target-card] -- Play card(pos), optionally targeting target-card owned by target-player." << endl;
			cout << "          use minion [target-player target-card] -- Use minion's special ability, optionally targeting target-card owned by target-player." << endl;
			cout << "          inspect minion -- View a minion's card and all enchantments on that minion." << endl;
			cout << "          hand -- Describe all cards in your hand." << endl;
			cout << "          board -- Describe all cards on the board." << endl;
		} else if (command == "end") {
            
            game.end_ritual(player);
            game.back_move(player);
            start = 0;
			first_turn = true;
            first_round = true;
			player = player==1?0:1;
            
			continue;

		} else if (command == "quit") {
			break;
		} else if (command == "draw") {
			if (test) {
				game.draw(player);
			} else {
				cout << "You are not in -testing mode" << endl;
			}
		} else if (command == "discard") {
			if (!test) {
				cout << "You are not in -testing mode" << endl;
				continue;
			}
			string s;
            if (command_list.size() >= (unsigned) 1) {
                s = command_list[0];
                command_list.pop_back();
            } else {
                getline(cin,s);
            }
			istringstream ss{s};

			int n;
			ss >> n;
			if (!ss) {
				cout << "not a valid number" << endl;
				continue;
			} else {
				game.discard(player,n-1);
			}

		} else if (command == "attack") {
			
			string line = "";
            if (command_list.size() > (unsigned) 0) {
                for (unsigned i = 0; i < command_list.size(); ++i) {
                    line += command_list[i];
                    line += " ";
                }
                command_list.clear();
            } else {
                getline(cin,line);
            }
			istringstream ss{line};
			int x = -1;
			int y = -1;
			
            
			ss >> x;
			if (!ss) {
				cout << "not a valid number" << endl;
				continue;
			} else {
                
                
				ss >> y;
				if (!ss) {
                    try {
                        game.attack(player,x-1);
                    } catch (string m){
                        cout << "Game Over!" << endl;
                        break;
                    }
				} else {
					game.attack(player,x-1,y-1);
				}
			}
		} else if (command == "play") {
			
			int i = -1;
			int p = -1;
			int t = -1;
            
            string line;
            if (command_list.size() > (unsigned) 0) {
                for (unsigned i = 0; i < command_list.size(); ++i) {
                    line += command_list[i];
                    line += " ";
                }
                command_list.clear();
            } else {
                getline(cin,line);
            }
			istringstream ss{line};

			ss >> i;
			if (!ss) {
				cout << "not a valid number" << endl;
				continue;
			} else {
				ss >> p;
				if (!ss) {
					game.play(player, i-1,test);
					continue;
				} else {
					ss >> t;
					if (!ss) {
                        ss.clear();
                        string target_minion;
                        ss >> target_minion;
                        if (target_minion == "r") game.play(player,i-1,p-1,test);
                        continue;
					} else {
						game.play(player,i-1,p-1,t-1,test);
					}
				}
			}
		} else if (command == "use") {
			int i = -1;
                        int p = -1;
                        int t = -1;

                        string line;
            if (command_list.size() > (unsigned) 0) {
                for (unsigned i = 0; i < command_list.size(); ++i) {
                    line += command_list[i];
                    line += " ";
                }
                command_list.clear();
            } else {
                        getline(cin,line);
            }
                        istringstream ss{line};

                        ss >> i;
                        if (!ss) {
                                cout << "not a valid number" << endl;
                                continue;
                        } else {
                                ss >> p;
                                if (!ss) {
                                    try {
                                        game.use(player, i-1,test);
                                        continue;
                                    } catch (string m) {
                                        cout << "Game Over" << endl;
                                        break;
                                    }
                                } else {
                                        ss >> t;
                                        if (!ss) {
                                                cout << "not a valid format" << endl;
                                                continue;
                                        } else {
                                                game.use(player,i-1,p-1,t-1,test);
                                        }
                                }
                        }
		} else if (command == "inspect") {
			int i;
			string s;
            if (command_list.size() > (unsigned) 0) {
                for (unsigned i = 0; i < command_list.size(); ++i) {
                    s += command_list[i];
                    s += " ";
                }
                command_list.clear();
            } else {
                getline(cin,s);
            }
			istringstream ss{s};
			ss >> i;
			if (!ss) {
				cout << "not a valid number" << endl;
				continue;
			}
			
			game.inspect(player,i-1);
		} else if (command == "hand") {
			game.displayHand(player);
		} else if (command == "board") {
			game.displayBoard();
        }
        
        
        
        
	}

}
