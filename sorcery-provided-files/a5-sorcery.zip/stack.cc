#include <memory>
#include <string>
#include <vector>
#include <iostream>
#include <utility>
using namespace std;

class Hello{
        public:
                vector<shared_ptr<string>> v;
                Hello() {}
                ~Hello() {}
                void init() {
                        v.push_back(make_shared<string>("asd"));
                        v.push_back(make_shared<string>("123"));
                }


};


class sad: public Hello {
	public:
		sad() {}
		~sad() {}
};


int main() {

	vector<shared_ptr<Hello>> list;
	list.push_back(make_shared<sad>());
	list[0]->init();
	cout << *list[0]->v[0] << endl;

}
