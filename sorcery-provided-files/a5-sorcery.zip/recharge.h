#ifndef _RECHARGE_H_
#define _RECHARGE_H_
#include "spell.h"
#include <string>

class Recharge : public Spell {
protected:
    std::string Desc;
    
public:
    Recharge();
    std::string getName() override;
    std::string getType() override;
    std::string getDesc() override;
};


#endif
