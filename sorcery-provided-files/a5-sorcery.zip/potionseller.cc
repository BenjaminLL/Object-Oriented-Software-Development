#include "potionseller.h"
using namespace std;

PotionSeller::PotionSeller() : Minion{2, 1, 1}, Desc{"At the end of your turn, all your minions gain +0/+1."} {}

string PotionSeller::getName() {
    return "Potion Seller";
}

string PotionSeller::getType() {
    return "minion_triggered_ability";
}

string PotionSeller::getDesc() {
    return Desc;
}
