#include "novicepyromancer.h"
using namespace std;

NovicePyromancer::NovicePyromancer() : Minion{1, 0, 1}, Desc{"Deal 1 damage to target minion"}, ability_cost{1} {}

string NovicePyromancer::getName() {
    return "Novice Pyromancer";
}

string NovicePyromancer::getType() {
    return "minion_activated_ability";
}

string NovicePyromancer::getDesc() {
    return Desc;
}

int NovicePyromancer::getAbilityCost() {
    return ability_cost + extra_cost;
}


void NovicePyromancer::addExtraCost(int i) {
    extra_cost += i;
}

void NovicePyromancer::clear_extra_cost() {
    extra_cost = 0;
}
