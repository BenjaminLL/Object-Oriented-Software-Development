#include "spell.h"
using namespace std;

Spell::Spell(int cost): Cards{cost}{}

Spell::~Spell() {}
