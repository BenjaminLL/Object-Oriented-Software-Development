#include "graveyard.h"

Graveyard::Graveyard() {}

Graveyard::~Graveyard() {}
