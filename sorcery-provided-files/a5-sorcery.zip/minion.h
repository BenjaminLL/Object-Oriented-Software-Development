#ifndef _MINION_H_
#define _MINION_H_
#include <memory>
#include <string>
#include "cards.h"

class Minion : public Cards {
protected:
    int atk;
    int def;
    int original_def;
    int extraAtk = 0;
    int extraDef = 0;
    bool moved = false;
    bool silence = false;
    bool shield = false;
    bool damage = false;
    std::shared_ptr<Cards> enchant;
    
public:
    Minion(int cost, int atk, int def);
    ~Minion() override;
    int getAttack() override;
    int getDefence() override;
    void getAttacked(int i) override;
    
    void clear() override;
    void addExtraAtk(int i) override;
    void addExtraDef(int i) override;
    
    std::shared_ptr<Cards> getEnchant() override;
    void setEnchant(std::shared_ptr<Cards> en) override;
    
    bool isSilence() override;
    void setSilence(bool b) override;

    std::string no_enchant(std::shared_ptr<Cards> c) override;
    
    void inspect() override;
    
    bool getMoved() override;
    void setMoved(bool b) override;
    
    void setDamage(bool b) override;
    bool getDamage() override;

    
};

#endif
