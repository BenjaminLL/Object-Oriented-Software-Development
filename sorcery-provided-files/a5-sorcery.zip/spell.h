#ifndef _SPELL_H_
#define _SPELL_H_
#include "cards.h"
#include <string>

class Spell : public Cards {
public:
    Spell(int cost);
    ~Spell() override;
};

#endif
