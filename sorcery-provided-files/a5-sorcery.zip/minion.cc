#include "minion.h"
#include <vector>
#include <iostream>
#include "ascii_graphics.h"
using namespace std;

Minion::Minion(int cost, int atk, int def): Cards{cost}, atk{atk}, def{def}, original_def{def} {}

Minion::~Minion() {}

int Minion::getAttack() {
    return atk + extraAtk;
}

int Minion::getDefence() {
    return def + extraDef;
}

void Minion::getAttacked(int i) {

    if (shield) {
        shield = false;
    } else {
        int remain = 0;
        if (extraDef > 0) {
            extraDef -= i;
            if (extraDef < 0) {
                remain = 0 - extraDef;
                extraDef = 0;
            }
        } else {
            remain = i;
        }
        def-=remain;
    }
}

void Minion::clear() {
    extraAtk = 0;
    extraDef = 0;
    silence = false;
    shield = false;
    enchant.reset();
    def = original_def;
 
}

void Minion::addExtraAtk(int i) {
    extraAtk += i;
}

void Minion::addExtraDef(int i) {
    extraDef += i;
}


bool Minion::isSilence() {
    return silence;
}

void Minion::setSilence(bool b) {
    silence = b;
}

void Minion::inspect() {
    //display the minion
    string type = getType();
    string name = getName();
    string desc = getDesc();
    int cost = getcost();
    
    vector<string> display_minion;
    if (damage) {
        display_minion = display_minion_activated_ability(name, cost, atk, def, 2, "Deal three damage to the opposite player");
    } else if (type  == "minion_no_ability") {
        display_minion = display_minion_no_ability(name, cost, atk, def);
    } else if (type ==  "minion_activated_ability") {
        int ability_cost = getAbilityCost();
        display_minion = display_minion_activated_ability(name, cost, atk, def, ability_cost, desc);
    } else if (type == "minion_triggered_ability") {
        display_minion = display_minion_triggered_ability(name, cost, atk, def, desc);
    }
    for (auto p : display_minion) {
        cout << p << endl;
    }
    //put display_enchants in a vector
    vector<vector<string>> displays;
    int num_enchant = 0;
    
    shared_ptr<Cards> temp_enchant = enchant;
    while(temp_enchant.use_count() != 0) {

        string enchant_type = temp_enchant->getType();

        string enchant_name = temp_enchant->getName();
        int enchant_cost = temp_enchant->getcost();
        string enchant_desc = temp_enchant->getDesc();
        vector<string> display_enchant;
        if (enchant_type == "enchantment") {

            
            display_enchant = display_enchantment(enchant_name, enchant_cost, enchant_desc);
        } else if (enchant_type == "enchantment_attack_defence") {

            
            string enchant_atk = temp_enchant->getAttack_entan();
            string enchant_def = temp_enchant->getDefence_entan();
            display_enchant = display_enchantment_attack_defence(enchant_name, enchant_cost, enchant_desc,
                                                                 enchant_atk, enchant_def);
        }
        
        ++num_enchant;
        temp_enchant = temp_enchant->getComp();
        displays.push_back(display_enchant);
    }
    

    //print the vector
    if (num_enchant != 0) {
        int current = 0;
        int size_enchant = displays[0].size();
        
        if (current + 4 < num_enchant) {
            while (current + 4 < num_enchant) {
                for (int m = 0; m < size_enchant; ++m) {
                    for (int n = current; n < current + 5; ++n) {
                        cout << displays[n][m];
                    }
                    cout << endl;
                }
                current += 5;
            }
        } else {
            
            for (int m = 0; m < size_enchant; ++m) {
                for (int n = 0; n < num_enchant-current; ++n) {
                    cout << displays[n][m];
                }
                cout << endl;
            }
        }
    }

}


shared_ptr<Cards> Minion::getEnchant() {
    return enchant;
}

void Minion::setEnchant(std::shared_ptr<Cards> en) {
    enchant = en;
}


string Minion::no_enchant(shared_ptr<Cards> c) {
    string enchant_type = c->getName();
    if (enchant_type == "Giant Strentment") {
        atk -= 2;
        if (extraDef > 0) {
            extraDef -= 2;
            if (extraDef < 0) {
                def += extraDef;
                if (def <= 0) {
                    return "minion dead";
                }
            }
        }
    } else if (enchant_type == "Magic Fatigue") {
        string less = "2";
        return less;
    } else if (enchant_type == "Silence") {
        silence = false;
    } else if (enchant_type == "Damage") {
        setDamage(false);
    }
    return "ok";
}

bool Minion::getMoved() {
    return moved;
}

void Minion::setMoved(bool b) {
    moved = b;
}

bool Minion::getDamage() {
    return damage;
}

void Minion::setDamage(bool b) {
    damage = b;
}
