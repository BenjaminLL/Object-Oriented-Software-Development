#include "mastersummoner.h"
using namespace std;

MasterSummoner::MasterSummoner() : Minion{3, 2, 3}, Desc{"Summon up to three 1/1 air elementals"}, ability_cost{2} {}

string MasterSummoner::getName() {
    return "Master Summoner";
}

string MasterSummoner::getType() {
    return "minion_activated_ability";
}

string MasterSummoner::getDesc() {
    return Desc;
}

int MasterSummoner::getAbilityCost() {
    return ability_cost + extra_cost;
}

void MasterSummoner::addExtraCost(int i) {
    extra_cost += i;
}

void MasterSummoner::clear_extra_cost() {
    extra_cost = 0;
}
