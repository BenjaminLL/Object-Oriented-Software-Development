#ifndef _PLAYER_H_
#define _PLAYER_H_
#include <string>
#include <vector>
#include <memory>
#include "collection.h"
#include "cards.h"

class Player {

  std::vector<std::shared_ptr<Collection>> collection_cards;
  std::string name;
  int life;
  int magic;
  int deck_pos = 0;
  int hand_pos = 1;
  int graveysard = 2;
  int board = 3;

  public:
    Player(std::string name);
    
    
    void changeMagic(int i);
    int getMagic();
    
    
    int getHP();
    void getAttacked(int i);
    int getAttack(int pos);
    std::vector<std::shared_ptr<Cards>> &getCollection_of_cards(int whichCollection);
    std::shared_ptr<Collection> getCollection(int whichCollection);
    
    void initial(std::string deck, bool test);
    void shuffle();
    
    void drawCard();
    void discard(int pos);
    void inspectCard(int pos);
    void showHand();
    
    std::shared_ptr<Cards> getRitual_on_board();
    
    

    void displayBoard(int player);
};

#endif





