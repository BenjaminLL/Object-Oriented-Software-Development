#include <vector>
#include <string>
#include <iostream>
#include "player.h"
#include "deck.h"
#include "hand.h"
#include "graveyard.h"
#include "board.h"
#include "ascii_graphics.h"
#include "ritual.h"
#include "enchantments.h"
#include "giantstrength.h"
#include "magicfatigue.h"
#include "silence.h"
#include "damage.h"
#include "auraofpower.h"
#include "darkritual.h"
#include "lightritual.h"
#include "standstill.h"
#include "spell.h"
#include "disenchant.h"
#include "banish.h"
#include "blizzard.h"
#include "recharge.h"
#include "clone.h"
#include "unsummon.h"
#include "raisedead.h"
#include "minion.h"
#include "airelemental.h"
#include "earthelemental.h"
#include "fireelemental.h"
#include "healer.h"
#include "potionseller.h"
#include "novicepyromancer.h"
#include "mastersummoner.h"
#include "apprenticesummoner.h"


using namespace std;

Player::Player(string name): life{20}, name{name}, magic{3} {}

void Player::changeMagic(int i) {

    magic += i;
    
}

int Player::getMagic() {
    return magic;
}

void Player::initial(string deck, bool test) {
	

	collection_cards.push_back(make_shared<Deck>(deck));
	collection_cards.push_back(make_shared<Hand>());
	collection_cards.push_back(make_shared<Graveyard>());
	collection_cards.push_back(make_shared<Board>());

    if (!test) {
	shuffle();
    }

    int num_deck = collection_cards[0]->getNum();
    if (num_deck < 4) throw "There are less than four cards in the deck.";
    
	vector<shared_ptr<Cards>> first_four;
    
	for (int i = 0; i < 4; ++i) {
		shared_ptr<Cards> temp = collection_cards[0]->getcard(0);
		first_four.push_back(temp);
		collection_cards[0]->detach(temp);
	}
    
    for (int i = 0; i < 4; ++i) {
        collection_cards[1]->attach(first_four[i]);
    }

}

void Player::shuffle() {
    collection_cards[deck_pos]->shuffle();
}


int Player::getHP() {
	return life;
}

void Player::getAttacked(int i) {
	life -= i;

    bool isRitual = collection_cards[3]->hasRitual();
    string ritual_name = "";
    if (isRitual) ritual_name = collection_cards[3]->getRitual()->getName();

    if (ritual_name == "Light Ritual") {
        if (collection_cards[3]->getRitual()->getRitualCharges() > 0) {
            life++;
            collection_cards[3]->getRitual()->addRitualCharges(-1);
        } else {
            cout << "Light Ritual does not have enough charges" << endl;
        }
    }

	if (life <= 0) throw "lose";
}

vector<shared_ptr<Cards>> &Player::getCollection_of_cards(int whichCollection) {
	return collection_cards[whichCollection]->getcards();
}

shared_ptr<Collection> Player::getCollection(int whichCollection) {
    return collection_cards[whichCollection];
}


int Player::getAttack(int pos) {
    vector<shared_ptr<Cards>> &board = getCollection_of_cards(3);
    int attack = board[pos]->getAttack();
    return attack;
}




void Player::drawCard() {
	vector<shared_ptr<Cards>> &deck = getCollection_of_cards(deck_pos);
	vector<shared_ptr<Cards>> &hand = getCollection_of_cards(hand_pos);

	if (deck.size() < 0) {
		cout << "There is no cards in the deck." << endl;
		return;
	}
    	if (hand.size() >= 5) cout << "Your hand is full." << endl;
	
	if (deck.size() > 0 && hand.size() < 5) {
		collection_cards[hand_pos]->attach(deck[0]);
		collection_cards[deck_pos]->detach(deck[0]);
    	}
    
}


void Player::discard(int pos) {
    vector<shared_ptr<Cards>> &hand = collection_cards[hand_pos]->getcards();
    hand.erase(hand.begin()+pos);
}


void Player::showHand() {
	vector<shared_ptr<Cards>> &hand = getCollection_of_cards(hand_pos);
	vector<card_template_t> display;

    for (auto card : hand) {
		string type = card->getType();
		string name = card->getName();
		int cost = card->getcost();
		int attack = card->getAttack();
		int defence = card->getDefence();
	if (type == "minion_no_ability") {
			display.push_back(display_minion_no_ability(name,cost,attack,defence));
        } else if (type == "minion_triggered_ability") {
			string description = card->getDesc();
			display.push_back(display_minion_triggered_ability(name,cost,attack,defence,description));
        } else if (type == "minion_activated_ability") {
            int ability_cost = card->getAbilityCost();
			string description = card->getDesc();
			display.push_back(display_minion_activated_ability(name,cost,attack,defence,ability_cost,description));
        } else if (type == "ritual") {
			int ritual_cost = card->getRitualCost();
			string description = card->getDesc();
			int ritual_charges = card->getRitualCharges();
			display.push_back(display_ritual(name,cost,ritual_cost,description,ritual_charges));
        } else if (type == "spell") {
			string description = card->getDesc();
			display.push_back(display_spell(name,cost,description));
		} else if (type == "enchantment_attack_defence") {
			string description = card->getDesc();
            string attack_ench = card->getAttack_entan();
            string defence_ench = card->getDefence_entan();
			display.push_back(display_enchantment_attack_defence(name,cost,description,attack_ench,defence_ench));
		} else if (type == "enchantment") {
			string description = card->getDesc();
			display.push_back(display_enchantment(name,cost,description));
        }
    
    }
	for (unsigned i = 0; i < display[0].size(); ++i) {
		for (unsigned k = 0; k < display.size(); ++k) {
			cout << display[k][i];
		}
		cout << endl;
	}
}



void Player::inspectCard(int pos) {
	vector<shared_ptr<Cards>> &minions = getCollection_of_cards(board);
    if (minions.size() <= pos) {
        cout << "There is no minion at the position: " << pos << endl;
    } else {
        minions[pos]->inspect();
    }
}

shared_ptr<Cards> Player::getRitual_on_board() {
	return collection_cards[board]->getRitual();
}

                              
                              
void Player::displayBoard(int player) {
    //minions
    vector<shared_ptr<Cards>> & all_minions = collection_cards[3]->getcards();
    int num_minions = all_minions.size();
    vector<vector<string>> printings;
    
        
    for (int i = 0; i < num_minions; ++i) {
        shared_ptr<Cards> minion = all_minions[i];
        string name = minion->getName();
        string type = minion->getType();
        string desc = minion->getDesc();
        int atk = minion->getAttack();
        int def = minion->getDefence();
        int cost = minion->getcost();
        
        bool damage = minion->getDamage();

        vector<string> print;
        if (damage) {
            print =  display_minion_activated_ability(name, cost, atk, def, 2, "Deal three damage to the opposite player");
        }else if (type  == "minion_no_ability") {
            print = display_minion_no_ability(name, cost, atk, def);
        } else if (type ==  "minion_activated_ability") {
            int ability_cost = minion->getAbilityCost();
            print = display_minion_activated_ability(name, cost, atk, def, ability_cost, desc);
        } else if (type == "minion_triggered_ability") {
            print = display_minion_triggered_ability(name, cost, atk, def, desc);
        }
        printings.push_back(print);
    }
    
    int size_printing = printings.size();
    if (size_printing < 5) {
	for(; size_printing < 5; ++size_printing) {
		   printings.push_back(CARD_TEMPLATE_BORDER);
	}
     }

    card_template_t display_ritual_board;
    //ritual
    if (collection_cards[3]->hasRitual()) {
        shared_ptr<Cards> ritual = collection_cards[3]->getRitual();
        string name = ritual->getName();
        string desc = ritual->getDesc();
        int ritual_cost = ritual->getRitualCost();
        int charges =  ritual->getRitualCharges();
        int cost = ritual->getcost();
        display_ritual_board = display_ritual(name,cost,ritual_cost,desc,charges);
    } else {
        display_ritual_board = CARD_TEMPLATE_BORDER;
    }
    
    vector<string> display_grave;
    
    //graveyard
    int num_grave = collection_cards[2]->getcards().size();
    if (num_grave > 0) {
        shared_ptr<Cards> & grave_top = collection_cards[2]->getcards()[num_grave-1];
        string name = grave_top->getName();
        string type = grave_top->getType();
        string desc = grave_top->getDesc();
        int atk = grave_top->getAttack();
        int def = grave_top->getDefence();
        int cost = grave_top->getcost();
    
        if (type  == "minion_no_ability") {
            display_grave = display_minion_no_ability(name, cost, atk, def);
        } else if (type ==  "minion_activated_ability") {
            int ability_cost = grave_top->getAbilityCost();
            display_grave = display_minion_activated_ability(name, cost, atk, def, ability_cost, desc);
        } else if (type == "minion_triggered_ability") {
            display_grave = display_minion_triggered_ability(name, cost, atk, def, desc);
        }
    } else {
        display_grave = CARD_TEMPLATE_BORDER;
    }



    //players
    if (player == 0) {
        vector<string> display_player = display_player_card(1, name, life, magic);
        int ritual_size = display_ritual_board.size();
        int minion_size = printings[0].size();
        
        //upper bound of player
        cout << EXTERNAL_BORDER_CHAR_TOP_LEFT;
        for (int a = 0; a < 33 * 5; ++a) {
            cout << EXTERNAL_BORDER_CHAR_LEFT_RIGHT;
        }
        cout << EXTERNAL_BORDER_CHAR_TOP_RIGHT << endl;
        
        // first line (ritual + empty + player + empty + graveyard)
        for (int i = 0; i < ritual_size; ++i) {
            cout << EXTERNAL_BORDER_CHAR_UP_DOWN << display_ritual_board[i] << CARD_TEMPLATE_EMPTY[i] << display_player[i] << CARD_TEMPLATE_EMPTY[i] << display_grave[i] << EXTERNAL_BORDER_CHAR_UP_DOWN << endl;
        }
        
        //second line (minions (<= 5))
        for (int m = 0; m < minion_size; ++m) {
            cout <<  EXTERNAL_BORDER_CHAR_UP_DOWN;
            for (int n = 0; n < 5; ++n) {
                cout << printings[n][m];
            }
            cout << EXTERNAL_BORDER_CHAR_UP_DOWN << endl;
        }
        
        //lower bound of player
     /*   cout << EXTERNAL_BORDER_CHAR_BOTTOM_LEFT;
          for (int a = 0; a < 33 * 5; ++a) {
            cout << EXTERNAL_BORDER_CHAR_LEFT_RIGHT;
        }
        cout << EXTERNAL_BORDER_CHAR_BOTTOM_RIGHT << endl;*/
    }

    if (player == 1) {
        vector<string> display_player = display_player_card(2, name, life, magic);
        int ritual_size = display_ritual_board.size();
        int minion_size = printings[0].size();
        
/*        //upper bound of player
        cout << EXTERNAL_BORDER_CHAR_TOP_LEFT;
        for (int a = 0; a < 33 * 5; ++a) {
            cout << EXTERNAL_BORDER_CHAR_LEFT_RIGHT;
        }
        cout << EXTERNAL_BORDER_CHAR_TOP_RIGHT << endl;
*/        
        //first line (minions (<= 5))
        for (int m = 0; m < minion_size; ++m) {
            cout <<  EXTERNAL_BORDER_CHAR_UP_DOWN;
            for (int n = 0; n < 5; ++n) {
                cout << printings[n][m];
            }
            cout << EXTERNAL_BORDER_CHAR_UP_DOWN << endl;
        }
        
        // second line (ritual + empty + player + empty + graveyard)
        for (int i = 0; i < ritual_size; ++i) {
            cout << EXTERNAL_BORDER_CHAR_UP_DOWN << display_ritual_board[i] << CARD_TEMPLATE_EMPTY[i] << display_player[i] << CARD_TEMPLATE_EMPTY[i] << display_grave[i] << EXTERNAL_BORDER_CHAR_UP_DOWN << endl;
        }
        
        //lower bound of player
        cout << EXTERNAL_BORDER_CHAR_BOTTOM_LEFT;
        for (int a = 0; a < 33 * 5; ++a) {
            cout << EXTERNAL_BORDER_CHAR_LEFT_RIGHT;
        }
        cout << EXTERNAL_BORDER_CHAR_BOTTOM_RIGHT << endl;
    }
}

