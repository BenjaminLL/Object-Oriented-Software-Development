#ifndef _SILENCE_H_
#define _SILENCE_H_
#include "cards.h"
#include "enchantments.h"
#include <string>

class Silence : public Enchantments {
public:
    Silence();
    std::string getType() override;
    std::string getDesc() override;
    std::string getName() override;
};


#endif
