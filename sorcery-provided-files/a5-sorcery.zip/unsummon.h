#ifndef _UNSUMMON_H_
#define _UNSUMMON_H_
#include "spell.h"
#include <string>

class Unsummon : public Spell {
protected:
    std::string Desc;
    
public:
    Unsummon();
    std::string getName() override;
    std::string getType() override;
    std::string getDesc() override;
};


#endif
