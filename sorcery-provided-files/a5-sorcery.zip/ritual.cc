#include "ritual.h"
using namespace std;

Ritual::Ritual(int cost, int ritualcost, int charge): Cards{cost}, ritualcost{ritualcost}, charge{charge} {}

Ritual::~Ritual() {}

int Ritual::getRitualCost() {
    return ritualcost;
}

int Ritual::getRitualCharges() {
    return charge;
}

void Ritual::addRitualCharges(int i) {
    charge+=i;
}
